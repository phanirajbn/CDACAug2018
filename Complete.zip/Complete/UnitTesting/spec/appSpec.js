var app = require('./math').calc;

//suite is a code that has one or more test functions in it. These test functions are called as Test Cases....
describe('First Test Suite', function() {
	//each test case is defined by a function called it..
	it('should add 2 numbers', function() {
		expect(app.addFunc(4,3)).toBe(7);
	});

	it('should subtract 2 numbers', function() {
		expect(app.subFunc(4,3)).toBe(1);
	});

	it('should throw error', function() {
		expect(app.subFunc(3,4)).toThrow("Invalid value");
	});
});