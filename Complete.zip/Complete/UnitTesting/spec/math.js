module.exports.calc = (function(){
	function addFunc(first, second){
		return first + second;
	}

	function subFunc(first, second){
		if(second > first)
			throw "Invalid value";
		return first - second;

	}

	return{
		addFunc : addFunc,
		subFunc : subFunc
	}
})();