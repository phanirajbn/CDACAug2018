describe('It should work with Arrays', function() {
	it('Should return -1 when value is not present', function(){
		expect([1,2,3].indexOf(5)).toBe(-1);
	})

	it("Should return index if the value is present", function(){
		expect([1,2,3].indexOf(2)).toBe(1);
	})
});