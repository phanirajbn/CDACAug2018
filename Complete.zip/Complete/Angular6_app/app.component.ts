import { Component } from '@angular/core';

@Component({
  selector: 'apple',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'SampleAngularApp';
}
