function add(first, second){
	return first + second
}

function subtract(first, second){
	return first - second;
}

function multiply(first, second){
	return first * second;
}

function divide(first, second){
	return first / second;
}
var res = add(123, 234);
console.log("The  value is " + res)

res = subtract(123, 234);
console.log("The subtracted value is " + res)

res = multiply(123, 234);
console.log("The multiplyed value is " + res)

res = divide(123, 234);
console.log("The divided value is " + res)
