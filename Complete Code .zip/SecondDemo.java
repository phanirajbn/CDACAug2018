import java.io.Console;//Represents the Console IO...
public class SecondDemo{
	public static void main(String[] args){
		//firstDemo();//displaying the output in different ways...
		//secondDemo();
		castingDemo();
	}

	private static void castingDemo(){
		float fValue = 234.345f;//Use f for floating values, else it considers it as double...
		int iValue = (int)fValue;//This is explicit casting as float is longer range compared to integer. 
		System.out.println("The Float Value: " + fValue +"\tThe integer after casting: " + iValue);
	}
	//Assignment: Get the range of all the primitive data types of java and display them in ascending order of their ranges. 

	//A group of statements to be grouped as a function, private as the function is not used outside/in any other class..
	private static void firstDemo(){
		System.out.println("Test 123");
		System.out.print("Test 123");//without a carrier return
		System.out.println("Test to see the difference");//Moves to next line after the printing..
		System.out.println("Testing again");		
		System.out.print("Can be done even like this\n");
		System.out.println("Testing again");
	}

  private static String getString(String question){
  	System.out.println(question);
  	return System.console().readLine();
  }

  private static int getNumber(String question){ 
  	return Integer.parseInt(getString(question));
  }

	//This function performs the input as well as the output...
	private static void secondDemo(){
	/*	System.out.println("Enter the name please");
		String answer = System.console().readLine();
		System.out.println("The name entered is " + answer);*/

		String name = getString("Enter the name please");
		String address = getString("Enter the address");
		int age = getNumber("Enter the age");

		System.out.println("The name entered is " + name +"\nThe Age is " + age  + "\nThe Address is " + address +".This person retires after " + (60 - age) +" years");		
	}
}