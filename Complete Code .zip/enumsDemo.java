//enums are enumerated consts for storing data in the form of integral types but are refered as strings.
//Use class if U want to have extended versions of the component thro Features of OOP..... 
/*class MachineStateType{
	public static int BUSY = 1;
	public static int IDLE = 2;
	public static int BLOCKED = 3;

}*/
enum MachineState{
	IDLE, BUSY, BLOCKED
}
//The class is intended to be used only within the package...
class Machine{
	MachineState state;
	public void setState(MachineState state){
		this.state = state;
	}

	public MachineState getState(){
		return this.state;
	}
}

public class enumsDemo{
	public static void main(String[] args){
		Machine myPC = new Machine();
		myPC.setState(MachineState.BUSY);
		System.out.println("The PC's current status is " + myPC.getState());
		//Taking inputs from the user for enums...
		System.out.println("Enter the state of UR PC from the list below");
		for(MachineState state : MachineState.values()){
			System.out.println("Machine state: " + state);
		}
		String value = System.console().readLine();
		MachineState state = MachineState.valueOf(value);
		switch(state){
			case BUSY:
				System.out.println(state + ", Please try later");
				break;
			case IDLE:
				System.out.println(state + ", At UR service");
				break;
			case BLOCKED:
				System.out.println(state + ", Already in use, wait for the operation to complete");
				break;
		}
	}
}