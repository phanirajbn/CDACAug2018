//Interactive data type program based on Seperation of Concerns...

//Operational Class using arithematic operators...
class MathCalc{
	public static double AddFunc(double first, double second){
		return first + second;
	}
	public static double SubFunc(double first, double second){
		return first - second;
	}
	public static double MulFunc(double first, double second){
		return first * second;
	}
	public static double DivFunc(double first, double second){
		return first / second;
	}
}

class InputClass{
	public static String getString(String question){
  	System.out.println(question);
  	return System.console().readLine();
  }

  public static double getNumber(String question){ 
  	return Double.parseDouble(getString(question));
  }
}

public class CalcProgram{
	public static void main(String[] args){
		String menu ="-------------MATH CALC-------------\nTo Add numbers: PRESS 1\nTo Subtract numbers: PRESS 2\nTo Multiply numbers: PRESS 3\nTo Divide numbers: PRESS 4\nPS:Anything else is considered as Exit....";
		boolean processing = true;
		do{
			String choice = InputClass.getString(menu);
			processing = processMenu(choice);
		}while(processing);
	}

	private static boolean processMenu(String choice){
		switch(choice){
			case "1":
				addNumbers();//helper function
				break;
			case "2":
				subtractNumbers();
				break;
			case "3":
				multiplyNumbers();
				break;
			case "4":
				divideNumbers();
				break;
			default:
				return false;
		}
		return true;
	}

	static void addNumbers(){
		double v1 = InputClass.getNumber("Enter the first value:");
		double v2 = InputClass.getNumber("Enter the second value:");
		double result = MathCalc.AddFunc(v1, v2);
		System.out.println("The added value is " + result);
	}
	static void subtractNumbers(){
		double v1 = InputClass.getNumber("Enter the first value:");
		double v2 = InputClass.getNumber("Enter the second value:");
		double result = MathCalc.SubFunc(v1, v2);
		System.out.println("The added value is " + result);
	}
	static void multiplyNumbers(){
		double v1 = InputClass.getNumber("Enter the first value:");
		double v2 = InputClass.getNumber("Enter the second value:");
		double result = MathCalc.MulFunc(v1, v2);
		System.out.println("The added value is " + result);
	}
	static void divideNumbers(){
		double v1 = InputClass.getNumber("Enter the first value:");
		double v2 = InputClass.getNumber("Enter the second value:");
		double result = MathCalc.DivFunc(v1, v2);
		System.out.println("The added value is " + result);
	}
}