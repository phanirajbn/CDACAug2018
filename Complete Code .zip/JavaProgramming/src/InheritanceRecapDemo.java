//It was on 23rd May 2018
class BaseClassRecap{
	public void baseFunc() {
		System.out.println("Base function defined in the base class");
	}
	
}

//Created on 23rd of October....
class DerivedClassRecap extends BaseClassRecap{
	
	public void baseFunc() {
		System.out.println("Base function defined in the derived class");
	}
	public void derivedFunc() {
		System.out.println("Derived Func defined in the derived class");
	}
}
public class InheritanceRecapDemo {
	public static void main(String[] args) {
		BaseClassRecap cls = new BaseClassRecap();
		cls.baseFunc();
		
		//All base class type objects could be instantiated to their subclasses...
		cls = new DerivedClassRecap();//There is no need for a new variable, U could use the same variable
		cls.baseFunc();//Runtime polymorphism where a base class variable instantiated to the derived type will invoke the overidden methods of the derived type than calling the base version..... 
		
		//As the data type of the object is base type, U cannot have access to the new methods created in the subclass. So we should downcast the variable to its subtype and then invoke the method......
		((DerivedClassRecap)cls).derivedFunc();
		
	}
}
