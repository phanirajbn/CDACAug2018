import java.lang.*;
import java.lang.reflect.*;
//Reflection is a process of examining or modifying the runtime behavior of a class at runtime. The java.lang.Class has methods to read the metadata of the type, examine it and change the runtime behavior of the object. The java.lang and java.lang.reflect packages help in providing classes required to read the metadata of a java type and get its info. These info could be used to invoke the methods at runtime based on the the client requests. The RTTI feature of C++ is based on this. The Reflection package is used to get info(reflect) about the class and its details. 
//details include everything about the class. Every part of the class is represented as objects. So U could read these info and determine what to do with it. A Class contains fields, methods, constructors, base types, derived types and many other information. 
//Practical usage of Reflection is: IDEs, Debugger tools, Testing tools, Viewers. 

class Mathclass{
	public double addFunc(double first, double second) {
		return first + second;
	}
	public double subFunc(double first, double second) {
		return first - second;
	}
	public double mulFunc(double first, double second) {
		return first * second;
	}
	public double divFunc(double first, double second) {
		return first / second;
	}
}
public class reflectionDemo {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
        /*Using Class.forName()***********************
         Class clsInfo = Class.forName("Mathclass");
        System.out.println(clsInfo.getName());
        Method[] methods = clsInfo.getMethods();
        for(Method m : methods)
        	System.out.println(m.getName());
		**********Using getClass() method...............
		Mathclass cls = new Mathclass();
		//All objects of java are derived from Object class....
		Class clsInfo = cls.getClass();
		System.out.println(clsInfo.getName());
        Method[] methods = clsInfo.getMethods();
        for(Method m : methods)
        	System.out.println(m.getName());
        ******************.class Syntax******************/
		//Class clsInfo =  Mathclass.class;//Every Class will have a static reference of the Class object using .class...This is available for primitive types also...
		//Class intInfo = int.class;
		System.out.println("Enter the name of the class U want to get dtails");
		String clsName = System.console().readLine();
		Class clsInfo = Class.forName(clsName);
		System.out.println(clsInfo.getName());
        Method[] methods = clsInfo.getMethods();
        for(Method m : methods)
        	System.out.println(m.getName());
        System.out.println("Enter the name of the method from the above list U want to get details");
		String mName = System.console().readLine();
		
        Class [] parameters = new Class[2];
        parameters[0] = double.class;
        parameters[1] = double.class;
        Method addDetails = clsInfo.getDeclaredMethod(mName, parameters);
        
        if(addDetails == null) {
        	System.out.println("Not a valid method in the class");
        	return;
        }
        System.out.println(addDetails.getName());
        System.out.println("The return type: " + addDetails.getReturnType().getName());
        System.out.println("The no of parameters:" + addDetails.getParameterCount());
        int no = addDetails.getParameterCount();
        for(Parameter cls: addDetails.getParameters()) {
        	System.out.println("Parameter Name: " + cls.getName());
        	System.out.println("Parameter type:" + cls.getType().getName());
        }
        
        Object instance = clsInfo.newInstance();//Create the instance of the class.
        Object result = addDetails.invoke(instance, 123, 234);
        System.out.println(result);
	}

}
