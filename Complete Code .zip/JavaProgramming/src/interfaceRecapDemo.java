class Gift{
	String name;
}
interface IParty{
	void Invite();
	void prepareCake();
	void orderFood();
	Gift providereturnGifts();
}

interface IDinner{
	void OrderDrinks();
}
class BirthDayDinnerparty implements IParty, IDinner{

	@Override
	public void Invite() {
		System.out.println("Send WhatsApp message to the group");		
	}

	@Override
	public void prepareCake() {
		System.out.println("Order cake from The FRENCH LOAF");
		
	}

	@Override
	public void orderFood() {
		System.out.println("Order Food from PARADISE");
	}

	@Override
	public Gift providereturnGifts() {
		return null;
	}

	@Override
	public void OrderDrinks() {
		System.out.println("Order Soda");	
	}
	
}

class SendOffParty implements IParty{

	@Override
	public void Invite() {
		System.out.println("Post messages to the email provider");
	}

	@Override
	public void prepareCake() {
		System.out.println("Prepare UR Self an EGGLESS CAKE");		
	}

	@Override
	public void orderFood() {
		System.out.println("Order Food from Mess");
	}


	@Override
	public Gift providereturnGifts() {
		// TODO Auto-generated method stub
		Gift gt =new Gift();
		gt.name ="Pen set";
		return gt;
	}
	
}
public class interfaceRecapDemo {

	public static void main(String[] args) {
		IParty party = new SendOffParty();
		party.Invite();
		party.prepareCake();
		party.orderFood();
		if(party.providereturnGifts() == null) {
			System.out.println("Bye See you!!!");
		}else
		{
			Gift gt = party.providereturnGifts();
			System.out.println("Thanks for gifting " + gt.name);
		}
		
		IDinner dinner  = (IDinner)party;
		dinner.OrderDrinks();
	}

}
