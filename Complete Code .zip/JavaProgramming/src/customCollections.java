import java.io.*;
import java.util.*;
class book implements Serializable{
	String title;
	int bookId;
	int bookPrice;
	
	public book(int id, String name, int price) {
		this.title = name;
		this.bookId = id;
		this.bookPrice = price;
	}
	//2 Books are equal if their title is same...
	@Override
	public int hashCode() {
		return this.title.hashCode();
	}
	@Override
	public boolean equals(Object other) {
		book bk = (book)other;//Unbox the type....
		return this.title.equals(bk.title);
	}
}
//If a Class has to be a collection class, it must implement an interface called Iterable. It provides an ability for UR object to be used in a foreach statement.
interface IBookstore extends Iterable<book>, Serializable {
	void addNewBook(book bk);
	void deleteBook(int id);
	void updateBook(book bk) throws Exception;
	List<book> getAllBooks();
	int count();
}

class bookserializationRepository implements IBookstore{
	bookRepository _store = new bookRepository();
	private String _file= "allBooks.ser";		
	@Override
	public Iterator<book> iterator() {
		return _store.iterator();
	}

	@Override
	public void addNewBook(book bk) {
		_store.addNewBook(bk);
		saveData();
	}

	private void saveData() {
		try {
			FileOutputStream fs = new FileOutputStream(_file);
			ObjectOutputStream os = new ObjectOutputStream(fs);
			os.writeObject(_store);
			os.close();
			fs.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deleteBook(int id) {
		_store.deleteBook(id);
		saveData();
	}

	@Override
	public void updateBook(book bk) throws Exception {
		_store.updateBook(bk);
		saveData();
	}

	@Override
	public List<book> getAllBooks() {
		// TODO Auto-generated method stub
		loadData();
		return _store.getAllBooks();
	}

	private void loadData() {
		try {
			FileInputStream fs = new FileInputStream(_file);
			ObjectInputStream os = new ObjectInputStream(fs);
			_store = (bookRepository)os.readObject();
			os.close();
			fs.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}

	@Override
	public int count() {
		// TODO Auto-generated method stub
		return _store.count();
	}
	
}
class bookRepository implements IBookstore, Serializable{
  private List<book> _books = new ArrayList<book>();
  
	public int count() {
		return _books.size();
	}
  @Override
	public Iterator<book> iterator() {
		return _books.iterator();//return  the iterator of the _books to iterate...
	}
	
	@Override
	public void addNewBook(book bk) {
		_books.add(bk);
		
	}

	@Override
	public void deleteBook(int id) {
		for(book bk : _books) {
			if(bk.bookId == id) {
				_books.remove(bk);
				return;//exit the function after the job is done, as the next iteration will throw an Exception....
			}
		}
	}

	@Override
	public void updateBook(book bk) throws Exception{
		throw new Exception("Not implemented, do it urself....");	
	}

	@Override
	public List<book> getAllBooks() {
		// TODO Auto-generated method stub
		return _books;
	}
	
}
public class customCollections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		customCollectionExample();
	}

	private static void customCollectionExample() {
		IBookstore store = new bookserializationRepository();
		/*store.addNewBook(new book(11,"Java cookbook", 450));
		store.addNewBook(new book(12,"Professional Java", 550));
		store.addNewBook(new book(13,"The Fairy tale theatre", 400));
		store.addNewBook(new book(14,"A Suitable Boy", 560));
		store.addNewBook(new book(15,"The Mahabharatha", 350));*/
		List<book> books =  store.getAllBooks();
		//What is it that makes the store a collection object?
		for(book bk : books)
			System.out.println(bk.title);
		
	}

}
