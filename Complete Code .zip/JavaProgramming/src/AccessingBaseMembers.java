//There are 2 keywords to represent objects in a generic manner. this and super. this refers to its own type and super represents its immediate base class...It is used to refer the parent class instance, constructor and methods.... 
class BaseClassSuper{
	BaseClassSuper(int id){
		System.out.println("ID is set as " + id);
	}
	public void Display() {
		System.out.println("Display");
	}
}
//By default, the derived class will call the default constructor of the base class. If the base class has only
final class DerivedClassSuper extends BaseClassSuper{
	DerivedClassSuper(){
		//explicitly call the base class parameterized constructor....
		super(123);
	}
}

class DerivedSuperDown{
	DerivedClassSuper superObj = new DerivedClassSuper();
	public void Display() {
		superObj.Display();
		System.out.println("Displaying further");
	}
}
public class AccessingBaseMembers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BaseClassSuper type = new DerivedClassSuper();
		DerivedSuperDown down = new DerivedSuperDown();
		down.Display();
				
	}

}
