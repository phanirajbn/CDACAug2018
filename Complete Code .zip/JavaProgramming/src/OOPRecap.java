//What is a class?
//A Class is a User defined that has some features of OOP like Inheritance, polymorphism, abstraction and ecapsulation. Its a reference type. They are instantiated using new operator...

class customer{
	
	private int id;//private members are not accessible outside the class it is declared....This concept is called as Encapsulation. There are different levels of Encapsulation: 
	/*
	 * 	private: accessible only within the class.
	 *  protected: accessible only within its family(subclasses) and its package. 
	 *  default: when no access specifier is mentioned, it is default. It is accessible within the package where it is declared. default is implied at the class level as well as member level.  
	 *  public: accessible anywhere within the Application and across the Application....
	 *  */
	private String name;
	private long contactNo;
	
	public customer(int id, String name, long no) {
		this.id = id;
		this.name = name;
		this.contactNo = no;
	}
	
	public int getEmpId() {
		return this.id;
	};
	public String getEmpName() {
		return name;
	}
	public long getPhoneNo() {
		return contactNo;
	}
}//U have created a prototype of the class. U have declared a new data type which composites other types based on the requirement of UR entity.

public class OOPRecap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//type of the class that can be instantiated to its type....
		customer cst = new customer(111,"Phaniraj", 5205684);//The data type of cst is customer...
		//it is creating an object of the type customer. 
		/*cst.contactNo =123;
		cst.id= 111;
		cst.name="phaniraj";Non accessible as they are private....*/
		System.out.println(String.format("The Phone no of Mr.%s is %d", cst.getEmpName(), cst.getPhoneNo()));
	}

}
