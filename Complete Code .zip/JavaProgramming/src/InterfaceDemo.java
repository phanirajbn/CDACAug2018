interface IExample{
	void ExampleFunc();//They are pure virtual functions/abstract methods...
}

interface ISimple{
	void SimpleFunc();
}


class Example implements IExample{
	@Override
	public void ExampleFunc() {
		System.out.println("Example function of the interface");	
	}	
}

class SimpleExample implements IExample, ISimple{
	private int value;
	@Override
	public void SimpleFunc() {
		System.out.println(value);
		System.out.println("Simple Func implementation");		
	}

	@Override
	public void ExampleFunc() {
		value = 123;
		System.out.println("Example Func implementation");		
	}
	
}

public class InterfaceDemo {

	public static void main(String[] args) {
		IExample ex = new SimpleExample();
		ex.ExampleFunc();//setting the value
		//Using the same object reference, no need to create new instance...
		ISimple sim = (ISimple)ex;
		sim.SimpleFunc();
		

	}

}
