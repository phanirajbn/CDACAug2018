import java.io.*;
class InputClass
{
	public static String getString(String question)
	{
		System.out.println(question);
		return System.console().readLine();
	}
	public static int getInteger(String question)
	{
		return Integer.parseInt(getString(question));
	}
}

public class ECommerceApp {
public static ProdStock db = new ProdStock(10); 
	public static void main(String[] args) {
		try
		{
			String productMenu = readFile(args[0]);
			boolean process = true;
			do
			{
				String choice = InputClass.getString(productMenu);
				process = processMenu(choice);
			}while(process==true);
		}
		catch(Exception ex)
		{ 
			System.out.println(ex.getMessage());
		}

	}
	
	private static boolean processMenu(String choice) throws Exception
	{
		switch(choice)
		{
		case "1":
			addRecord();
			return true;
		case "2":
			deleteRecord();
			return true;
		case "3":
			updateRecord();
			return true;
		case "4":
			readAllRecords();
			return true;
		}
		return false;
	}
	private static void addRecord()
	{
		int id= InputClass.getInteger("Enter the Product Id");
		String name= InputClass.getString("Enter the Product Name");
		int quantity= InputClass.getInteger("Enter the Product Quantity");
		Product prod = new Product();
		prod.setProdDetails(id, name, quantity);
		try
		{
			db.addNewProduct(prod);
			System.out.println("Product added successfully to the cart");
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
private static void readAllRecords()
{
	Product[] records = db.getAllProducts();
	for(Product prod: records)
	{
		String information = String.format("The Name: %s\nThe Quantity: %s\nThe Id: %d", prod.getProdName(), prod.getProdQuantity(), prod.getProdId());
		System.out.println(information);
	}
}
 private static void deleteRecord()
 {
	 int id = InputClass.getInteger("Enter the Product Id to delete the product");
	 try
	 {
		 db.deleteProduct(id);
		 System.out.println("Product Deleted Successfully");
	 }
	 catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
 }
 
 private static void updateRecord()
	{
		int id= InputClass.getInteger("Enter the Product Id to update Product");
		String name= InputClass.getString("Enter the new Product Name");
		int quantity= InputClass.getInteger("Enter the new Product Quantity");
		Product prod = new Product();
		prod.setProdDetails(id, name, quantity);
		try
		{
			db.updateProduct(prod);
			System.out.println("Product updated successfully to the cart");
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}
private static String readFile(String file) throws Exception{
	StringBuilder data = new StringBuilder("");
	FileReader reader = new FileReader(file);
	int i = 0;
	while((i = reader.read())!=-1) {
		data.append((char)i);
	}
	reader.close();
	return data.toString();
}
}
//.......................................................Entity layer................................
class Product
{
	private int prodId;
	private String prodName;
	private int prodQuantity;
	
	public void setProdDetails(int id, String name, int quantity)
	{
		prodId = id;
		prodName= name;
		prodQuantity = quantity;
	}
	
	public int getProdId()
	{
		return prodId;
	}
	public String getProdName()
	{
		return prodName;
	}
	public int getProdQuantity()
	{
		return prodQuantity;
	}
}

//...............................................Data Access Layer..............................
class ProdStock
{
	private Product[] prodList = null;
	public ProdStock(int size) {
		prodList = new Product[size];
		prodList[0] = new Product();
		prodList[0].setProdDetails(111, "TestName", 5);
		
		prodList[1] = new Product();
		prodList[1].setProdDetails(112, "ObjName", 5);
		
		prodList[2] = new Product();
		prodList[2].setProdDetails(113, "OtherName", 5);
	}
	public void addNewProduct(Product prod) throws Exception
	{
		for(int i=0; i<prodList.length;i++)
		{
			if(prodList[i]== null)
			{
				prodList[i]=new Product();
				prodList[i].setProdDetails(prod.getProdId(), prod.getProdName(), prod.getProdQuantity());
				return;
			}
		}
		throw new Exception("Stock is full");
	}
	public void deleteProduct(int id) throws Exception
	{
		int index = getProduct(id);
		if(index==-1)
			throw new Exception("Product not found to delete");
		prodList[index] = null;
		
	}
	public int getProduct(int id)
	{
		for(int i=0; i<prodList.length;i++)
		{
			if((prodList[i]!=null)&& (prodList[i].getProdId() == id))
			{
				return i;
			}
		} return -1;
	}
	public void updateProduct(Product prod) throws Exception
	{
		int index = getProduct(prod.getProdId());
		System.out.println(prod.getProdName());
		if(index==-1)
			throw new Exception("Product is not present in the stock");
		String oldName = prodList[index].getProdName();
		System.out.println(oldName);
		prodList[index].setProdDetails(prod.getProdId(), (prod.getProdName() == "" || prod.getProdName() == null ? oldName : prod.getProdName()), prod.getProdQuantity());
	}
	public Product[] getAllProducts() 
	{
		Product[] copy = new Product[0];
		Product[] tempCopy = null;
		for(Product prod : prodList) 
		{
			if(prod!=null) 
			{
				tempCopy = copy.clone();
				copy = new Product[tempCopy.length+1];
				System.arraycopy(tempCopy,0,copy,0,tempCopy.length);
				copy[copy.length-1]=prod;
			}
		}
		return copy;
	}
}

	
	


