import java.io.*;
import java.util.*;
//Java;s FileWriter and Reader class is used to write/read charecter oriented data to a file. It allows to read each charecter or write charecters to a file(Text based files).  It is far better than the FileOutputStream class that reads the data as bytes and U should do the type conversions....
class Student{
	int id;
	String name;
	String address;
	
	public Student(int id, String name, String address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}
	@Override
	public String toString() {
		return String.format("%d,%s,%s", id, name, address);
	}
}
public class filedemo {

	public static void main(String[] args) {
		//writeToFile();
		readFromFile();
	}

	private static void readFromFile() {
		/*try {
			String filename = "TestFile.txt";
			FileReader reader = new FileReader(filename);
			int i;
			while((i = reader.read()) != -1){
				System.out.print((char)i);
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		try {
			String filename = "Data.csv";
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String line = "";
			List<Student> allStudents = new ArrayList<Student>();
			while((line = reader.readLine()) != null) {
				String[] values = line.split(",");
				Student s = new Student(Integer.parseInt(values[0]), values[1], values[2]);
				allStudents.add(s);
			}
			for(Student s : allStudents)
				System.out.println(s);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void writeToFile() {
	/*	try {
		FileWriter writer = new FileWriter("E:\\Test\\TestFile.txt");
		Student student = new Student(111,"TestName","TestAddress");
		String content = student.toString();
		writer.write(content);
		writer.close();
		}catch(IOException ex) {
			ex.printStackTrace();
		}*/
		List<Student> students = new ArrayList<Student>();
		students.add(new Student(111, "TestName","Hyderabad"));
		students.add(new Student(112, "Phaniraj","Bangalore"));
		students.add(new Student(113, "Suresh","Chennai"));
		students.add(new Student(114, "Kiran Kumamr","Pune"));
		try {
			FileWriter writer = new FileWriter("Data.csv");
			for(Student s : students) {
				String line = s.toString();
				writer.write(line+"\n");
			}
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
