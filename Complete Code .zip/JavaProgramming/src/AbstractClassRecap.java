import java.util.*;
import java.lang.reflect.*;
//abstract classes are classes which have atleast one abstract method. abstract methods are non implemented methods. 
abstract class Account{
	
	int accNo;
	String cstName;
	private double balance;
	
	public void Credit(double amount) {
		balance += amount;
	}
	
	public void Debit(double amount)throws Exception {
		if(amount > balance)
			throw new Exception("Insufficient funds");
		balance -= amount;
	}
	
	public double getBalance() {
		return balance;
	}
	public abstract void calculateInterest();
}

class SBAccount extends Account{

	@Override
	public void calculateInterest() {
		double amount = this.getBalance() * 1/2 * 6.5/100;
		this.Credit(amount);
	}
	
}

class FDAccount extends Account{

	@Override
	public void calculateInterest() {
		double amount = this.getBalance()  * 6.5/100;
		this.Credit(amount);
	}
	
}

class RDAccount extends Account{

	@Override
	public void calculateInterest() {
		double amount = this.getBalance() * 1/2 * 6.5/100 + 100;
		this.Credit(amount);
	}
	
}

class CCAccount extends Account{

	@Override
	public void calculateInterest() {
		double amount = this.getBalance() * 1/12 * 3.5/100;
		this.Credit(amount);
		
	}
	
}

class AccountFactory{
	public static Account createAccount(String accType)throws Exception {
		Class type = Class.forName(accType);
		if(type == null)
			return null;
		return (Account)type.newInstance();
		/*switch(accType) {
		case  "SB":
			return new SBAccount();
		case "RD":
			return new RDAccount();
		case "FD":
			return new FDAccount();
		case "CC":
			return new CCAccount();
		default:
				throw new Exception("No such account exists with us");
		}*/
	}
}
public class AbstractClassRecap {

	public static void main(String[] args) throws Exception {
		ResourceBundle r = ResourceBundle.getBundle("test");
		String name = r.getString("accType");
		Account acc = AccountFactory.createAccount(name);//Instantiate the abstract class...
		acc.Credit(5000);
		acc.calculateInterest();//The derived class version will be called
		System.out.println(acc.getBalance());
		
		acc = AccountFactory.createAccount(name);//Instantiate the abstract class...
		acc.Credit(5000);
		acc.calculateInterest();//The derived class version will be called
		System.out.println(acc.getBalance());
	}

}
