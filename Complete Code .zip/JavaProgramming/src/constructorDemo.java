//This demo is created to explain about constructors...

class Infotainment{
	String cdPlayer;
	String navigator;
	int sensors;
	String speakers;
	
	//It is easy to set values to my fields in one single statement.....
	Infotainment(String player, String navigator, int sensors, String speakers){
		this.cdPlayer = player;
		this.navigator = navigator;
		this.sensors = sensors;
		this.speakers = speakers;
	}
	
	void play() {
		System.out.println("The Infotainment is playing music and display the Route navigation of the Road");
	}
}

class Car{
	private Infotainment entertainer;
	//try commenting this constructor first and then uncomment it to see the difference...
	Car(Infotainment copy){
		this.entertainer = copy;
	}
	public void RunTheCar() {
		System.out.println("The Car is running at the speed of 65km/hr");
		entertainer.play();
	}
}
public class constructorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car hondaWrv = new Car(new Infotainment("SONY", "GOOGLE NAVIGATOR", 6, "JBL with ultra Sound"));
		hondaWrv.RunTheCar();
	}

}
