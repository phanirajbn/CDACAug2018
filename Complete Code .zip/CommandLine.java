import java.io.*;//Get the reference of all File IO classes required....
//import java.nio.*;

public class CommandLine{
	public static void main(String[] args) throws Exception{
		//firstExample(args);
		//readFile(args[0]);
		readingFileNewway(args[0]);
	}

  prrivate static void readingFileNewway(String file)throws Exception{
  		byte[] code = Files.readAllBytes(file);
		String data = new String(code, null);
		System.out.println(data);
  }
	private static void readFile(String file){
		try{
		FileReader reader = new FileReader(file);//Syntax for instantiating a class in Java....
		int i =0;
		while((i =reader.read()) != -1){
			System.out.print((char)i);
		}
		reader.close();
		}
		catch(Exception ex){
          System.out.println(ex.getMessage());
		}
	}

	private static void firstExample(String[] args){
	for(int i= 0; i< args.length;i++){
			System.out.println(args[i]);
		}
	}
}