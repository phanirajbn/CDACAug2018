public class StringsDemo{
	public static void main(String[] args){
		//immutableExample();
		StringBuilderExample();
	}
	static void StringBuilderExample(){
		StringBuilder sb = new StringBuilder("Hello ");
		sb.append(" String Example");
		System.out.println(sb);
	}
	static void immutableExample(){
		String s1 = "Apple";
		String s2 = "Apple";//No new memory is created for the 2nd variable as they share the same data. This is the feature of the String Constant pool
		s2 = s2.concat(" is good for health");//now it creates a new string...
		if(s2.contains("Apple")){
			System.out.println("They are talking about apple");
		}else{
			System.out.println("They are talking about something else");
		}
		System.out.println("The Name of the fruit is " + s1);	
		System.out.println("The Name of the fruit is " + s1.toLowerCase());
		//Converts the string to lower case and returns a new string	
		System.out.println("The Name of the fruit is " + s1.toUpperCase());
		System.out.println("The part of the fruit is " + s1.substring(1,4));
		//extracts a part of the string from start index to end index...
        
        String s = "An Apple a Day keeps the doc away";
        String[] words = s.split("\\s");//Used to split the words...
        for(String word: words)
        	System.out.println(word);

        String password = "    Apple    ";
        System.out.println(password =="Apple");
        String trimmedValue = password.trim();//romoves the white spaces...
        System.out.println(password.trim().length() == "Apple".length());
        System.out.println(trimmedValue == "Apple");
        System.out.println(trimmedValue +"fruit");//check if the string is trimmed
        System.out.println(password +"fruit");
        String name="Phaniraj";
        String address = "Bangalore";
        int id = 123;
        String output = String.format("The name is %s,\nHis Address is %s\nHis ID is provided as %d", name, address, id);
        System.out.println(output);

        String n1 ="Akshay";
        String n2 ="Suresh";
        System.out.println(n1.compareTo(n2));
        n2= "Akshay";
        System.out.println(n1.compareTo(n2));
	}
}