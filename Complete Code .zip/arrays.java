public class arrays{
	public static void main(String[] args){
		//firstDemo();
		//secondDemo();
		//thirdDemo();
		fourthDemo();
	}
	/*
	All arrays are objects of the class called System.array. With this object U could get additional information about the array...
	*/
	static void fourthDemo(){
		int arr [] = {3,4,5,6};
		Class cls = arr.getClass();//Gets the classname of the object..
		String name = cls.getName();
		System.out.println("The name of the class of this object is " + name);//Provides the [I] as the output...Array of the type integer...
	}
	/*
	This is the example of Jagged Arrays in Java. Array of Arrays is called as Jagged array. Similar to multi dimensional array, but each row will have variable no of columns.
	*/
	static void thirdDemo(){
		int[][] classrooms = new int[4][];
		classrooms[0] = new int[]{2,3,4,5};
		classrooms[1] = new int[]{2,3,4,5,6,7,8,6,5,4,3,4,6,6};
		classrooms[2] = new int[]{2,3,4,5,6,5,4,6};
		classrooms[3] = new int[]{2,3,4};
		//Here each row represents an independent array...
		for(int i=0; i<classrooms.length;i++){
			for(int value  : classrooms[i]){
				System.out.print(value + " ");
			}
			System.out.println();
		}
	}

	/**
	This is the example of multi dimensional Array...
	*/
	static void secondDemo(){
		int[][] school = new int[2][2];
		school[0][0] = 1;
		school[0][1] = 2;
		school[1][0] = 3;
		school[1][1] = 4;
		//Using a nested loop to display in a matrix format...
		/*for (int i =0;i < 2 ; i++ ) {
			for(int j =0; j < 2; j++){
				System.out.print(school[i][j] + " ");
			}
			System.out.println();//blank line to move to next line
		}*/
		for(int i=0; i< school.length;i++){//no of columns
			for(int j=0; j<school[i].length;j++){//no of rows..
				System.out.print(school[i][j] + " ");	
			}
			System.out.println();//blank line to move to next line
		}
	}
    
    /**
    This is the Simple array example in Java
    */
	static void firstDemo(){
		int months[] = new int[12];//creating arrays....
		months[0] = 31;//accessing members of the array
		months[1] = 28;
		months[2] = 31;
		months[3] = 30;
		months[4] = 31;
		months[5] = 30;
		months[6] = 31;
		months[7] = 31;
		months[8] = 30;
		months[9] = 31;
		months[10] = 30;
		months[11] = 31;
		
		//reading the elements of the array thro index...
		System.out.println("The April month has " + months[3] +" days");
		System.out.println("The January month has " + months[0] +" days");
		System.out.println("The December month has " + months[11] +" days");

		for(int i =0; i < months.length; i++){
			System.out.println("Month: " + months[i]);
		}
		
		System.out.println("Using foreach equivalent");
		//Similar to foreach statement...
		for(int item : months){
			System.out.println("Month: " + item);
			//With this, it is forward only and without a need of index.
		}
	}
}