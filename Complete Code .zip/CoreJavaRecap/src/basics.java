//java is both a programming language and a platform. Platform: An environment where the program executes. The OS is called hardware environment and Java/.NET are called as Software platform as they are executed on top of the OS...
//2 types: Primitive and Reference type. Variable definition is to tell the runtime about a memory allocated so that we wish to use it later. Variable data could be modified. The place once created cannot be used for other types. local(Scoped), instance(Class based), static(Singleton). 

class empNotFoundException extends Exception{
	public empNotFoundException() {
	}
	
	public empNotFoundException(String msg) {
		super(msg);
	}
	
	
}
public class basics {
	static {
		System.out.println("Called before  main");
	}
	public static void main(String[] args)throws empNotFoundException {
		/*staticClass cls = new staticClass();
		staticClass.testValue = 432;
		cls = new staticClass();
		cls = new staticClass();
		cls = new staticClass();
		cls = new staticClass();
		cls = new staticClass();
		cls = new staticClass();
		cls = new staticClass();*/
		throw new empNotFoundException("cannot be updated as no employee is found");
		/*employee emp = new employee();
		emp.testFunc();*/
		/*
		apple fruit = new custardApple("Nagpur apple");
		fruit.display();*/
	}//javac(compilation) and java(execution) commands from the command prompt...

}//public class name should always be the same name as the filename, so a given file, U will have only one public class 

class staticClass{
	public static int testValue;
	public int instanceValue;
	
	staticClass(){
		System.out.println("Instance is created");
	}
	
	//Static constructors....
	static {
		testValue = 123;
		System.out.println("Static block is called");
	}
}
class employee{
	int instanceVariable = 123;
	static int staticVariable = 234;
	public void testFunc() {
		int localVariable = 123;
		System.out.println(localVariable);
		System.out.println(this.instanceVariable);
		System.out.println(employee.staticVariable);
	}
}

class apple{
	String name ="kashmir apple";
	public apple() {
		System.out.println("Basic apple is created");
	}
	public apple(String name) {
		this();//Call other constructor inside a constructor.... 
		this.name = name;
		System.out.println(name + " apple is created");
	}
	public void display() {
		System.out.println(name);
	}
}

class custardApple extends apple{
	public custardApple(String name) {
		super(name);//call the base class constructor explicitly...
	}
	@Override
	public void display() {
		super.display();
		System.out.println("Extending the existing functionality");
	}
}