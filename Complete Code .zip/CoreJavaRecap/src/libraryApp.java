import java.io.*;
import java.sql.*;
import java.util.*;

class Book{
	int bookId;
	String title;
	String author;
	double price;
	
	public Book(int id, String name, String author, double price) {
		this.bookId = id;
		this.title = name;
		this.author = author;
		this.price = price;
	}
	@Override
	public String toString() {
		return String.format("%d,%s,%s,%f", bookId, title, author, price);
	}
}

interface IDalLibrary{
	void addNewBook(int id, String title, String author, double price);
	void updateBook(int id, String title, String author, double price);
	ResultSet getBooks();
	void deleteBook(int id);
}

class DalComponent implements IDalLibrary{
	String url = "jdbc:mysql://localhost/CDACTraining";
	String user ="root";
	String pwd="";
	String strInsert="insert into bookstore values(?,?, ?, ?)";
	String strSelect ="SELECT * FROM BOOKSTORE";
	String update = "UPDATE BOOKSTORE SET TITLE=?, AUTHOR=?, PRICE=? WHERE BOOKID=?";
	String delete ="delete from bookstore where bookid= ?";
	@Override
	public void addNewBook(int id, String title, String author, double price) {
		
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement(strInsert);
			ps.setInt(1, id);
			ps.setString(2, title);
			ps.setDouble(3, price);
			ps.setString(4, author);
			ps.executeUpdate();		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private Connection getConnection()throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, user, pwd);
		return con;
	}

	@Override
	public void updateBook(int id, String title, String author, double price) {
		
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement(update);
			ps.setInt(4, id);
			ps.setString(1, title);
			ps.setDouble(3, price);
			ps.setString(2, author);
			ps.executeUpdate();		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public ResultSet getBooks() {
		
		ResultSet data = null;
		try {
			Connection con = getConnection();
			Statement s = con.createStatement();
			data = s.executeQuery(strSelect);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

	@Override
	public void deleteBook(int id) {
		
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement(update);
			ps.setInt(1, id);
			ps.executeUpdate();		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

interface IBusLibrary{
	void addBook(Book book);
	void updateBook(Book book);
	List<Book> getBooksByTitle(String title);
	List<Book> getBooksByAuthor(String author);	
	void deleteBook(int id);
}

class BusComponent implements IBusLibrary{
	private IDalLibrary lib = new DalComponent();
	@Override
	public void addBook(Book book) {
		lib.addNewBook(book.bookId, book.title, book.author, book.price);
	}

	@Override
	public void updateBook(Book book) {
		lib.updateBook(book.bookId, book.title, book.author, book.price);	
	}

	private List<Book> allBooks(){
		ResultSet set = lib.getBooks();
		ArrayList<Book> books = new ArrayList<Book>();
		try {
			while(set.next()) {
				Book bk = new Book(set.getInt(1), set.getString(2),set.getString(4),set.getDouble(3));
				books.add(bk);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return books;
	}
	@Override
	public List<Book> getBooksByTitle(String title) {
		List<Book> books = allBooks();
		List<Book> onlyTitles = new ArrayList<Book>();
		for(Book bk : books) {
			if(bk.title.contains(title))
				onlyTitles.add(bk);
		}
		return onlyTitles;
	}

	@Override
	public List<Book> getBooksByAuthor(String author) {
		List<Book> books = allBooks();
		List<Book> onlyTitles = new ArrayList<Book>();
		for(Book bk : books) {
			if(bk.author.contains(author))
				onlyTitles.add(bk);
		}
		return onlyTitles;
	}

	@Override
	public void deleteBook(int id) {
		lib.deleteBook(id);	
	}
	
}

class Input{
	static int getInteger(String question) {
		return Integer.parseInt(getString(question));
	}
	static double getDouble(String question) {
		return Double.parseDouble(getString(question));
	}
	static String getString(String question) {
		String input = "";
		try{
			System.out.println(question);
			InputStreamReader reader = new InputStreamReader(System.in);
			BufferedReader kb = new BufferedReader(reader);
			input = kb.readLine();
			return input;
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		return input;
	}
}
public class libraryApp {
   static IBusLibrary busObj = new BusComponent();
   
	public static void main(String[] args) {
		String menu = readFile(args[0]);
		boolean processing = true;
		do {
			String choice = Input.getString(menu);
			processing = processMenu(choice);
		} while (processing);
	}

	private static boolean processMenu(String choice) {
		// TODO Auto-generated method stub
		switch(choice) {
		case "1":
			addRecord();
			return true;
		case "2":
			updateRecord();
			return true;
		case "3":
			deleteRecord();
			return true;
		case "4":
			searchByTitle();
			return true;
		case "5":
			searchByAuthor();
			return true;	
		}
		return false;
	}

	private static void searchByAuthor() {
		List<Book> books = busObj.getBooksByAuthor(Input.getString("Enter the name of the author to search"));
		for(Book bk : books)
			System.out.println(bk);
	}

	private static void searchByTitle() {
		List<Book> books = busObj.getBooksByTitle(Input.getString("Enter the name of the Title to search"));
		for(Book bk : books)
			System.out.println(bk);
	}

	private static void deleteRecord() {
		int id = Input.getInteger("Enter the id of the book to delete");
		busObj.deleteBook(id);
	}

	private static void updateRecord() {
		int id = Input.getInteger("Enter the ID to update");
		String name = Input.getString("Enter the title to update");
		String author = Input.getString("Enter the Author to update");
		double price = Input.getDouble("Enter the cost to update");
		Book bk = new Book(id, name, author, price);
		busObj.updateBook(bk);
	}

	private static void addRecord() {
		int id = Input.getInteger("Enter the ID to add");
		String name = Input.getString("Enter the title to add");
		String author = Input.getString("Enter the Author to add");
		double price = Input.getDouble("Enter the cost to add");
		Book bk = new Book(id, name, author, price);
		busObj.addBook(bk);
		
	}

	private static String readFile(String string) {
		StringBuilder builder = new StringBuilder("");
		try{ 
			FileReader reader = new FileReader(string);
			int i =0;
			while((i = reader.read()) != -1) {
				builder.append((char)i);
		}
			reader.close();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
			return builder.toString();
	}

}
