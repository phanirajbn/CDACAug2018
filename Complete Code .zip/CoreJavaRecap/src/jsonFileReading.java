import java.io.FileReader;
import java.util.*;

import org.json.simple.*;

import jdk.nashorn.internal.parser.JSONParser;

class emp{
	public int empId;
	public String empName;
	
	emp(int id, String name){
		this.empId = id;
		this.empName = name;
	}
	
	@Override
	public String toString() {
		return String.format("%d,%s", empId, empName);
	}
}
public class jsonFileReading {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		//displayJson();
		String fileName = "data.json";
		JSONParser parser = new JSONParser(fileName, null, false);
		
		try {
			JSONArray list = (JSONArray)parser.parse();
			System.out.println(list);
			}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	private static void displayJson() {
		JSONArray array = new JSONArray();
		List<emp> empList = new ArrayList<emp>();
		empList.add(new emp(123, "Phaniraj"));
		empList.add(new emp(124, "TestName"));
		array.addAll(empList);
		System.out.println(array.toJSONString());
	}

}
