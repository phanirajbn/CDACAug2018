interface IExample{
	default void exampleFunc() {
		System.out.println("Default implementation");
	}
	
	void simpleFunc();
}

interface ITest{
	void testFunc();
}

interface IMathFunc{
	double mathOp(double v1, double v2);
}


class Example implements IExample{
	@Override
	public void simpleFunc() {
		System.out.println("simple func");
	}
	
}
public class defaultIntefaceExample {

	public static void main(String[] args) {
	/*		IExample ex = new Example();
			ex.exampleFunc();
			ex.simpleFunc();*/
		
/*		ITest t = ()->{System.out.println("Test Func implemented in implementor");};
		t.testFunc();*/
		IMathFunc addFunc = (v1, v2) -> v1 + v2;
		System.out.println(addFunc.mathOp(123,  234));
		
		IMathFunc mulFunc = (v1, v2) -> v1 * v2;
		double res = mulFunc.mathOp(3, 2);
		System.out.println(res);
		
		
	}

}
