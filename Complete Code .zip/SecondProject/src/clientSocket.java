import java.io.*;
import java.net.*;

public class clientSocket {

	public static void main(String[] args) {
		try {
			//Create a socket to the server address...
			Socket sock = new Socket("localhost", 4321);
			//create a writing stream to write to the server.
			DataInputStream din = new DataInputStream(sock.getInputStream());
			//create a reading stream to read from the server...
			DataOutputStream dou = new DataOutputStream(sock.getOutputStream());
			//maintain a loop to write and read from the server....
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			String input ="";
			String output = "";
			while(!input.equals("End")) {
				input = reader.readLine();
				dou.writeUTF(input);
				dou.flush();
				output = din.readUTF();
				System.out.print(output);
			}
			dou.close();
			din.close();
			sock.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//close all the sockets and the Streams....
	}

}
