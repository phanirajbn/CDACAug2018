package DataLayer;

import java.util.List;

import Entities.employee;

public interface DalInterface {
	void addNewEmployee(int id, String name, String address);
	void updateEmployee(int id, String name, String address);
	void deleteEmployee(int id);
	List<employee> getAllEmployees();
}
