package DataLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Entities.employee;

public class DalComponent implements DalInterface {
	
	static String url ="jdbc:mysql://localhost/Cdactraining";
    static String user ="root";
    static String password ="";
    
    private static Connection getConnection() throws Exception {
    	Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("Connection succeeded");
		return con;
    }
	@Override
	public void addNewEmployee(int id, String name, String address) {
		try {
			String strInsert = "INSERT INTO EMPTABLE VALUES(?,?,?)";
			Connection con = getConnection();
			PreparedStatement query = con.prepareStatement(strInsert);
			query.setInt(1, id);
			query.setString(2, name);
			query.setString(3, address);
			query.executeUpdate(strInsert);	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}

	}

	@Override
	public void updateEmployee(int id, String name, String address) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<employee> getAllEmployees() {
		List<employee> empList = new ArrayList<employee>();
		try {
			Connection con = getConnection();
			Statement query = con.createStatement();
			ResultSet rs = query.executeQuery("SELECT * FROM EMPTABLE");
			
			while(rs.next()) {
				employee emp = new employee(rs.getInt(1), rs.getString(2), rs.getString(3));
				empList.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList;
	}

}
