package Entities;

public class employee {
	private String empName;
	private String empAddress;
	private int empId;
	
	public employee(int id, String name, String addr) {
		this.empAddress = addr;
		this.empName = name;
		this.empId = id;
	}
	
	public int getId() { return this.empId;}
	
	public String getName() { return this.empName;}
	
	public String getAddress() { return this.empAddress;}
}
