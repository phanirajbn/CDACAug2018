import java.sql.*;
import java.util.List;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import BusinessLayer.BalInterface;
import BusinessLayer.BussComponent;
import Entities.employee;
//JDBC is the set of APIs that are used for interacting with databases. Java Database Connectivity API is a set of APIs created for interacting with all kinds of databases using Java. It works on various kinds of databases and also on various kinds of platforms. 
//With JDBC Apis U can perform all the CRUD operations required for database programs. 
/*Any DB Connecting App needs the following things:
 * A Driver/Adapter to bridge b/w the OS and the Database Software. 
 * A set of APIs for performing the complex Operations like Connectivity, parsing of SQL statements, reading the data and interprocess communication b/w the App and the Database.
 * Java uses different kinds of drivers for connecting the database like the JDBC Driver, Native drivers, network drivers and light weight drivers. 
 * JDBC drivers are most preferred choice of the driver. 
 * JDBC works on tabular kind of data storages. In other words for relational databases.  
 * All the important interfaces, classes required for database interaction are available under the package java.sql. 
 * The important interfaces are:
 * Connection: interface that contains methods to connect to the db and perform operations like open, close, set the required connection details.
 * Statement: For creating SQL statements that are executed thro the connection.
 * ResultSet: The extracted data from the SELECT statement that is provided with a cursor to read the data.
 * Rowset: Represents each row from the obtained RecordSet. 
 * */
/*5 steps of JDBC:
 * Register the driver.
 * Obtain the connection
 * Create Statement
 * Execute the Query
 * Close the Connection
 * */
public class dbProgram {
    public static String url ="jdbc:mysql://localhost/Cdactraining";
    public static String user ="root";
    public static String password ="";
    public static String strSelect ="SELECT * FROM EmpTable";
    public static String strInsert="INSERT INTO EMPTABLE VALUES(130,'Akash', 'Delhi')";
    public static String strdelete ="DELETE FROM EMPTABLE WHERE EMPID =130";
    public static String strUpdate ="Update Emptable Set empName=?, empAddress=? where empid=?";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       try {
    	   displayRecords();
    	   //insertRecord();
    	   //deleteRecord();
    	   //updateRecord(123, "Phani raj B.N.", "Bengaluru");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	private static void updateRecord(int empid,String empName, String empAddress) throws Exception {
		/*Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement(strUpdate);
		ps.setString(1, empName);
		ps.setString(2, empAddress);
		ps.setInt(3, empid);
		int rowsAffected = ps.executeUpdate();
		System.out.println("The no of rows affected:" + rowsAffected);*/
		BalInterface busObj = new BussComponent();
		busObj.updateEmployee(new employee(130, "BalName","BalAddress"));
	}

	private static void deleteRecord() throws Exception {
		/*Connection con = getConnection();
		Statement query = con.createStatement();
		int rowsAffected = query.executeUpdate(strdelete);
		System.out.println("The no of rows Affected:" + rowsAffected);*/
		BalInterface busObj = new BussComponent();
		busObj.deleteEmployee(123);
		
	}

	private static void insertRecord() throws Exception {
		/*Connection con = getConnection();
		Statement query = con.createStatement();
		int rowsAffected = query.executeUpdate(strInsert);
		System.out.println("The no of rows Affected:" + rowsAffected);*/
		BalInterface busObj = new BussComponent();
		busObj.addNewEmployee(new employee(130, "BalName","BalAddress"));
	}

	private static void displayRecords() throws Exception {
		/*Connection con = getConnection();
		Statement query = con.createStatement();
		ResultSet rs = query.executeQuery(strSelect);
		while(rs.next()) {
			System.out.println(String.format("%d,%s,%s", rs.getInt(1), rs.getString(2), rs.getString(3)));
		}*/
		BalInterface busObj = new BussComponent();
		List<employee> list = busObj.getAllEmployees();
		for(employee emp : list) {
			System.out.println(emp.getName());
		}
	}

	private static Connection getConnection() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("Connection succeeded");
		return con;
	}

}
