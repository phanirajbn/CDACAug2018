package BusinessLayer;

import java.util.List;
import Entities.employee;
import DataLayer.*;

public class BussComponent implements BalInterface {
   private DalInterface dalObj = new DalComponent();
	
	@Override
	public void addNewEmployee(employee emp) throws Exception {
		// TODO Auto-generated method stub
		//Check for the business rules here....
		if(emp == null)
			throw new Exception("Employee details are not set");
		dalObj.addNewEmployee(emp.getId(), emp.getName(), emp.getAddress());
	}

	@Override
	public void updateEmployee(employee emp) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<employee> getAllEmployees() {
		return dalObj.getAllEmployees();
	}

}
