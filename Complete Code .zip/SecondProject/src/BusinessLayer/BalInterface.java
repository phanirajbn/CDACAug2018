package BusinessLayer;
import Entities.*;
import java.util.*;

public interface BalInterface {
	void addNewEmployee(employee emp) throws Exception;
	void updateEmployee(employee emp) throws Exception;
	void deleteEmployee(int id) throws Exception;
	List<employee> getAllEmployees();
}
