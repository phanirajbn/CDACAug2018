//Networking in java: Network programming means to write programs that can execute across different machines and multiple devices. These machines are connected thro any kind of networks like tcp/ip, internet or any other means.
//java.net package contain the classes required for performing network related programs. Examples of network related programs are broadcastings, chatting apps, Antivirus software, DB programming and many more...
//Socket programming is the most common way of performing Network related Apps using TCP. Sockets provide communication b/w 2 machines using TCP. A server app will provide a gateway thro which clients can communicate. The Client program creates the socket object and tries to access the machine where the Server socket resides. 
//Server provides the services thro IP Address and a port no associated with that machine. This port no is like a gateway thro which communication happens. The client apps will create the sockets from their end to access the server socket specifying the published IP Address of the server along with the port no where the data is available. 
//sockets internally use streams to interact with the applications. Servers and clients need both input and output streams to interact with each other...
import java.net.*;
import java.io.*;

public class socketsServer {
	public static void main(String[] args) {
		try {
			ServerSocket ss = new ServerSocket(4321);
			Socket sock = ss.accept();//This is to accept the requests made by the client to UR app....
			
			DataInputStream ds = new DataInputStream(sock.getInputStream());
			DataOutputStream dou = new DataOutputStream(sock.getOutputStream());
			
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			String input = "";
			String output ="";
			
			while(!input.equals("End")) {
				input = ds.readUTF();//For strings...
				System.out.println("Client:" + input);
				output = br.readLine();
				dou.writeUTF(output);
				dou.flush();
			}
			ds.close();
			ss.close();
			sock.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
