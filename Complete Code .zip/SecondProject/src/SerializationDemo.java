import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

//Serialization is a mechanism of converting the state of the object into a byte stream. Deserialization is a reverse process of converting the created byteStream into an object. The idea is to save the object state across the different streams and processes, so that we could write in one App and read the contents from another app. The Persistance(Saving) could be to a file, memory or an external database. The byte stream that U create would be platform independent, which means that the object saved in one platform, could be read from another platform. 
//PS: Serialization is not File IO. It does more that that. The file io is writing/reading raw data as byte[] or char[]. Here the state of the object will be written in the byte format which include not only the data but also the metadata of the object that U have stored(Class info, package info, application info and many more). The purpose of the serialization is for IPC Apps. 
//Any Serialization will have 3 things to do:
/*
 * What to serialize? Any objects of Java classes that implements Java.io.serializable. 
 * Where to Serialize: As memory objects, file objects or data Streams.
 * How to save? The implementor class will contain methods to serialize and deserialize. 
 * */
//Serializable is a marker interface(Attributes). It is an interface with no data member or method. It is used to mark the java classes so that the objects of that class may get some additional capabilities with which U could do some operations. Some of the other examples are Clonable, Remote(Remote architecture). 

class Employee implements Serializable{
	public int empId;
	public String empName;
	public String empAddress;
	@Override
	public String toString() {
		return String.format("%s from %s with id %d", empName, empAddress, empId);
	}
}
public class SerializationDemo {
	private static Employee _data = null;
	private static String _file = "Data.ser";
	public static void main(String[] args) {
		/*_data = new Employee();
		_data.empId = 123;
		_data.empName ="Phaniraj";
		_data.empAddress ="Bangalore";
		saveData();*/
		
		loadData();
				
		
	}
	private static void loadData() {
		try {
			FileInputStream fs = new FileInputStream(_file);
			ObjectInputStream os = new ObjectInputStream(fs);
			_data = (Employee)os.readObject();
			System.out.println(_data);
			os.close();
			fs.close();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	private static void saveData() {
		try {
			FileOutputStream fs = new FileOutputStream(_file);
			
			//For serialization purpose, U should use ObjectOutputStream and ObjectInputStream.
			ObjectOutputStream os = new ObjectOutputStream(fs);
			os.writeObject(_data);
			os.close();
			fs.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
