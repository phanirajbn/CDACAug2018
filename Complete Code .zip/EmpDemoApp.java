import java.io.*;

class InputClass{
	public static String getString(String question){
  	System.out.println(question);
  	return System.console().readLine();
  }

  public static double getDouble(String question){ 
  	return Double.parseDouble(getString(question));
  }

  public static int getInteger(String question){ 
  	return Integer.parseInt(getString(question));
  }
}
/*****************UI layer of the Application***************/
public class EmpDemoApp{
	private static EmpRepository db = new EmpRepository(InputClass.getInteger("Enter the no of Employees in the organization"));

	public static void main(String[] args){
		try{
			String menu = readFile(args[0]);
	    	boolean processing = true;
	   	    do{
				String choice = InputClass.getString(menu);
				processing = processMenu(choice);
			}while(processing == true);	
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	private static boolean processMenu(String choice) throws Exception{
		switch(choice){
			case "1":
			   addRecord();
			   return true;
			case "2":
				deleteRecord();
				return true;
			case "3":
			    updateRecord();
			    return true;
			case "4":
				readAllRecords();
			    return true;
		}
		return false;
	}

	private static void readAllRecords(){
		Employee[] records = db.getAllEmployees();
		for(Employee emp : records){
			String details = String.format("The Name: %s\nThe Address: %s\nThe Id: %d", emp.getEmpName(), emp.getEmpAddress(), emp.getEmpID());
			System.out.println(details);
		}
	}
	private static void updateRecord(){
		int id = InputClass.getInteger("Enter the ID of the Employee to update");
		String name = InputClass.getString("Enter the new Name");
		String address = InputClass.getString("Enter the new Address");
		Employee emp = new Employee();
		emp.setDetails(id, name, address);
		try{
			db.updateEmployee(emp);
			System.out.println("Employee updated to the database");

		}catch(Exception ex){
			System.out.println(ex.getMessage());			
		}
	}
	private static void deleteRecord(){
		int id = InputClass.getInteger("Enter the ID of the Employee to delete");
		try{
			db.deleteEmployee(id);
			System.out.println("Employee deleted successfully");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	private static void addRecord(){
		int id = InputClass.getInteger("Enter the Id of the Employee");
		String name = InputClass.getString("Enter the Name of the Employee");
		String address = InputClass.getString("Enter the Address of the Employee");
		Employee emp = new Employee();
		emp.setDetails(id, name, address);
		try{
			db.addNewEmployee(emp);
			System.out.println("Employee added successfully");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	private static String readFile(String file) throws Exception{
		StringBuilder contents = new StringBuilder("");
		FileReader reader = new FileReader(file);
		int i =0;
		while((i = reader.read())!= -1){
			contents.append((char)i);
		}
		reader.close();
		return contents.toString();
	}
}
/*---------------------Entities Layer-----------------------------*/
class Employee{
	private int empID;
	private String empName;
	private String empAddress;

	public void setDetails(int id, String name, String addr){
		empID = id;
		empName = name;
		empAddress = addr;
	}

	public int getEmpID(){
		return empID;
	}

	public String getEmpName(){
		return empName;
	}

	public String getEmpAddress(){
		return empAddress;		
	}
}
/***************************Data access layer*****************/
class EmpRepository{
	private Employee[] empList = null;

	 public EmpRepository(int size){
	 	empList = new Employee[size];
	 	empList[0] = new Employee();
	 	empList[0].setDetails(111, "Phaniraj","Bangalore");
	 	
	 	empList[3] = new Employee();
	 	empList[3].setDetails(114, "Suresh","Mysore");
	 	empList[1] = new Employee();
	 	empList[1].setDetails(111, "Deshpande","Pune");
	 }

	 public void addNewEmployee(Employee emp) throws Exception{
	 	for (int i =0; i< empList.length ;i++ ) {
	 		if(empList[i] == null){
	 			empList[i] = new Employee();
	 			empList[i].setDetails(emp.getEmpID(), emp.getEmpName(), emp.getEmpAddress());
	 			return;
	 		}
	 	}
	 	throw new Exception("Employee could not be added");
	 }

	 public void deleteEmployee(int id) throws Exception{
	 	int index = getEmployee(id);
	 	if(index == -1)
	 		throw new Exception("Employee not found to delete");
	 	empList[index] = null;//remove the employee from the list
	 }

	 public void updateEmployee(Employee emp)throws Exception{
        int index = getEmployee(emp.getEmpID());
        if(index == -1)
        	throw new Exception("Employee not found to update");
        //empList[index] = new Employee();
        empList[index].setDetails(emp.getEmpID(), (emp.getEmpName() =="" ? empList[index].getEmpName(): emp.getEmpName()), emp.getEmpAddress());
	 }
     public Employee[] getAllEmployees(){
     	//create a copy...
     	Employee [] copy = new Employee[0];
     	//create a tempCopy...
     	Employee [] tempCopy = null;
     	//run thro the loop of the original
     	for(Employee emp : empList){
     		//check for non null value
     		if(emp != null){
     	//copy the copy to the tempCopy..
     			tempCopy = copy.clone();
     	//append the copy with 1
     			copy = new Employee[tempCopy.length+ 1];
     	//copy back the contents of tempCopy to copy
     			System.arraycopy(tempCopy, 0, copy, 0, tempCopy.length);
     	//set the last position to the found emp obj
     			copy[copy.length- 1] = emp;
     		}//continue...
     	}		
     	return copy;
     }
	 private int getEmployee(int id){
	 	for(int i=0; i < empList.length;i++){
	 		if((empList[i] != null) && (empList[i].getEmpID() == id)){
	 			return i;	
	 		}
	 	}
	 	return -1;
	 }
}