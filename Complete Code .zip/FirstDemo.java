/*
Created on 8th Nov 2018
First java program
Developed by:Phaniraj B.N.
*/

//package com.phani.javaProgramming;
import java.lang.System;
import java.lang.String;

//The name of the class should be same as the filename
public class FirstDemo{
	public static void main(String args[]){
		System.out.println("Testing Java App");//prints a stream of text on the output device(Console)
	}
}
//com.phani.javaProgramming.FirstDemo