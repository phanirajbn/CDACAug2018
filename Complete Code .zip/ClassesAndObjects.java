public class ClassesAndObjects{
	public static void main(String[] args){
		firstDemo();
		secondDemo();
	}
	/*
	  Using default access specifier, comment this code if U want to execute
	*/
	static void firstDemo(){
/*		Employee emp = new Employee();
		emp.empId = 123;
		emp.empName = "Phaniraj";
		emp.empAddress = "Bangalore";
		System.out.println(String.format("The name is %s with Address at %s and id of %d", emp.empName, emp.empAddress, emp.empId));*/
	}

	static void secondDemo(){
		Employee emp = new Employee();
		//private members are accessible thro public or default members(only within the same package)...
		emp.setDetails(123, "Phaniraj","Bangalore");
		emp.displayDetails();
	}
}

class Employee{
	private int empId;
	private String empName;
	private String empAddress;

	public void setDetails(int id, String name, String address){
		empId = id;
		empName = name;
		empAddress = address;
	}

	public void displayDetails(){
		System.out.println(String.format("The name is %s with Address at %s and id of %d", empName,  empAddress,  empId));
	}
}